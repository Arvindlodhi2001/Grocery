import React from 'react'

const HomeFooter = () => {
  return (
    <div>HomeFooter</div>
  )
}

export default HomeFooter